import React from 'react'

const SongsList = () => {
  return (
    <div>SongsList</div>
  )
}

export default SongsList